def p(g):
	C=sum(g,[]);A=next(A for A in C[::-1]if A);D=(set(C)-{0,A}).pop()
	for(E,B)in enumerate(zip(*g)):
		if D in B and A in B[(G:=19-B[::-1].index(D))+1:]:
			for F in range(G,20):g[F][E]=g[F][E]or A
	return g