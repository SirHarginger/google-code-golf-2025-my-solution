z=range(17)
p=lambda g:[[g[A][B]if g[A][B]==g[A%6][B%6]else g[5][0]for B in z]for A in z]