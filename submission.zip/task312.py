def p(j):
	for A in j:
		for B in A:A[:]=[B*(A==5)+A*(A!=5)for A in A]
	return j