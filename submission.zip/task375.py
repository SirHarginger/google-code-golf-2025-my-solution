def p(j):
 for A in range(len(j)):j[A][A]=j[-A-1][A]=0
 return j