def p(g,e=range):
 g=[[r for r in r if r>0]for r in g if r.count(0)<2];g=[[r[0]]*10for r in g+g+g]
 for r in e(10):
  for A in e(10):g[r][A]=g[A][r]
 return g[:10]