def p(j,A=range):
	for B in A(len(j[0])):
		for C in A(len(j)):
			if j[C][B]:break
		for D in A(C,len(j)):j[D][B]=j[C][B]
	return j