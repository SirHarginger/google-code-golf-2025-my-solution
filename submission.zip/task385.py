def p(j,A=enumerate):
	for(B,D)in A(j):
		for(C,E)in A(D):j[B][C]=j[-(B+1)][C]
	return j