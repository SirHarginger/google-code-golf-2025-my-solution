def p(j):
 for a in range(len(j[0])):
  if j[-1][a]==2:
   c=0
   for e in range(len(j)):
    if j[~e][a+c]==5:c+=1;j[-e][a+c]=2
    j[~e][a+c]=2
 return j