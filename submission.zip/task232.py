def p(g):
	for B in g:
		A=-1
		for(D,C)in enumerate(B):
			if C:E=C;A=0
			if~A:B[D]=(E,5)[A];A^=1
	return g