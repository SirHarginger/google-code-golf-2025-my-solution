def p(r):
 for A in range(1,len(r[0])):r[-1][A]=4;r[A-1][-A]=2
 return r