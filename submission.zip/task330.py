def p(g):
 for _ in g*4:l=0;g=[[[(a>0)*b|a,(a>0)<<(l:=l+1)][a%2]for a,b in zip(r,[*r[1:],0])]for r in zip(*g[::-1])]
 return[[(s>0)+(s.bit_count()==6)for s in r]for r in g]