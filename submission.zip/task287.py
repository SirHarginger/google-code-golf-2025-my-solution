def p(g):
	C=range(len(g))
	def A():
		for A in C:
			for B in C:
				if g[A][B]==4:g[A][B]=D[A][B]
	D=g[::-1];A();D=[A[::-1]for A in g];A();return g